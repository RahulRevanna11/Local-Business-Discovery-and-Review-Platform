import React from "react";
import "./HomePage.css";


const Footer = () =>{
    return (
        <>
            <footer className="footer font">
                <h2>Quicklinks &copy; all rights reserved</h2>
            </footer>
        </>
    )
}
export default Footer;