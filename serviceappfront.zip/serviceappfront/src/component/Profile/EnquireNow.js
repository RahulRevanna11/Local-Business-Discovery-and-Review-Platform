import React from 'react'
import "./EnquireNow.css"
const EnquireNow = () => {
  return (
    <div className='body  all  '>
       
<section >
  <div class="content ">
    <h2>Enquire </h2>
    <h2>Enquire </h2>
  </div>
</section>
    </div>
  )
}

export default EnquireNow